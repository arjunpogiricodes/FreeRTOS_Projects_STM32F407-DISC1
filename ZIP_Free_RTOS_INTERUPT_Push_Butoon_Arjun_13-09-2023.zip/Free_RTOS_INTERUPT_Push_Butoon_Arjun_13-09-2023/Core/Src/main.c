/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <FreeRTOS.h>
#include <task.h>


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

static void led_GREEN_handler (void *parameters);
static void led_RED_handler (void *parameters);
static void led_BLUE_handler (void *parameters);
static void led_ORANGE_handler (void *parameters);
/*static void BUTTON_handler (void *parameters);*/
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

TaskHandle_t Green_Led;
TaskHandle_t Red_Led;
TaskHandle_t Blue_Led;
TaskHandle_t Orange_Led;
TaskHandle_t Button_press;
TaskHandle_t volatile next_press = NULL;



/*uint16_t button_read =0;*/

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	BaseType_t Status;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */


 Status =  xTaskCreate(led_GREEN_handler, "green", 200, NULL, 3, &Green_Led);
 configASSERT(Status==pdPASS);
 next_press = Green_Led;

 Status =  xTaskCreate(led_RED_handler, "red", 200, NULL, 2, &Red_Led);
 configASSERT(Status==pdPASS);


 Status =  xTaskCreate(led_BLUE_handler, "blue", 200, NULL, 1, &Blue_Led);
 configASSERT(Status==pdPASS);


 Status =  xTaskCreate(led_ORANGE_handler, "orange", 200, NULL, 4, &Orange_Led);
 configASSERT(Status==pdPASS);



/* Status =  xTaskCreate(BUTTON_handler, "button", 200, NULL, 4, &Button_press);
 configASSERT(Status==pdPASS);*/


 vTaskStartScheduler();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GREEN_Led_Pin|ORANGE_Led_Pin|RED_Led_Pin|BLUE_Led_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : GREEN_Led_Pin ORANGE_Led_Pin RED_Led_Pin BLUE_Led_Pin */
  GPIO_InitStruct.Pin = GREEN_Led_Pin|ORANGE_Led_Pin|RED_Led_Pin|BLUE_Led_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
  /* EXTI interrupt init*/

/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void push_button_intrupt(void)
{
	BaseType_t pxHigherPriorityTaskWoken;

	pxHigherPriorityTaskWoken = pdFALSE;



	xTaskNotifyFromISR(next_press,0,eNoAction,&pxHigherPriorityTaskWoken);

	/* once the ISR exits, the below macro makes higher priority task which got unblocked to resume on the CPU */
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);



}

static void led_GREEN_handler (void *parameters){

BaseType_t Status ;
	while(1)
	{
		  HAL_GPIO_TogglePin(GPIOD, GREEN_Led_Pin);


		  Status = xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(500));

		  if(Status == pdTRUE)
		  {
			portENTER_CRITICAL();
			next_press = Red_Led;
			portEXIT_CRITICAL();
			HAL_GPIO_WritePin(GPIOD,GREEN_Led_Pin,GPIO_PIN_SET);
			vTaskDelete(NULL);

		  }

	}
}

static void led_RED_handler (void *parameters){

	BaseType_t Status ;
	while(1)
	{
		HAL_GPIO_TogglePin(GPIOD, RED_Led_Pin);

		  Status = xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(100));

		  if(Status == pdTRUE)
		  {
			  portENTER_CRITICAL();
			next_press = Blue_Led;
			portEXIT_CRITICAL();
			HAL_GPIO_WritePin(GPIOD,RED_Led_Pin,GPIO_PIN_SET);
			vTaskDelete(NULL);

		  }

	}
}

static void led_BLUE_handler (void *parameters){

	BaseType_t Status ;
	while(1)
	{
		HAL_GPIO_TogglePin(GPIOD, BLUE_Led_Pin);

		  Status = xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(250));

		  if(Status == pdTRUE)
		  {
			  portENTER_CRITICAL();
			next_press = Orange_Led;
			portEXIT_CRITICAL();
			HAL_GPIO_WritePin(GPIOD,BLUE_Led_Pin,GPIO_PIN_SET);

			vTaskDelete(NULL);

		  }

	}
}

static void led_ORANGE_handler (void *parameters){

	BaseType_t Status ;

	while(1)
	{
		HAL_GPIO_TogglePin(GPIOD, ORANGE_Led_Pin);

		  Status = xTaskNotifyWait(0,0,NULL,pdMS_TO_TICKS(350));

		  if(Status == pdTRUE)
		  {
			  portENTER_CRITICAL();
			next_press = NULL;
			portEXIT_CRITICAL();

			HAL_GPIO_WritePin(GPIOD,ORANGE_Led_Pin,GPIO_PIN_SET);

			vTaskDelete(NULL);

		  }

	}
}

/*static void BUTTON_handler (void *parameters){


	uint8_t new_button = 0;
	uint8_t old_button = 0;

	while(1)
	{
    new_button = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);

    if (new_button)
    {
    	if(! old_button)

    	xTaskNotify(next_press,0,eNoAction);
    }
    	old_button = new_button;
    	vTaskDelay(pdMS_TO_TICKS(10));




	}

}*/

/*
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

	button_read=1;

}
*/


/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM5 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM5) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

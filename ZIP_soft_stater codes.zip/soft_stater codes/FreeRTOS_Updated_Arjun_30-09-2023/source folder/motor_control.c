/*
 * motor_control.c
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#include <motor_control.h>






void Motor_On()
{

/*
	  //Turning on Input Relay 4 and 5
	  HAL_GPIO_WritePin(GPIOA, RELAY_4_Pin, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, RELAY_5_Pin, GPIO_PIN_RESET);

*/

	  //Turning on Output Relay 1 and 2
	  HAL_GPIO_WritePin(GPIOA, Relay_2_Pin|Relay_1_Pin, GPIO_PIN_RESET);




}

void Motor_Off()
{
	  //Turning on Input Relay 4 and 5
/*	  HAL_GPIO_WritePin(GPIOA, RELAY_4_Pin, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, RELAY_5_Pin, GPIO_PIN_SET);*/


	  //Turning on Output Relay 1 and 2
	  HAL_GPIO_WritePin(GPIOA, Relay_2_Pin|Relay_1_Pin, GPIO_PIN_SET);




}




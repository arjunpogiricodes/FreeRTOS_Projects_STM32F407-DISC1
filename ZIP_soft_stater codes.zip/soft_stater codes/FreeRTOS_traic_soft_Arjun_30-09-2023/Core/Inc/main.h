/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "FreeRTOS.h"
#include "task.h"
#include "stdio.h"
#include "string.h"
#include <stdbool.h>
#include "math.h"
#include  "queue.h"
#include "spi_source.h"
#include "i2c_source.h"
#include "mqtt_quectel_source.h"
#include "motor_control.h"

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

extern I2C_HandleTypeDef hi2c1;

extern SPI_HandleTypeDef hspi1;

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;






/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define POWER_KEY_Pin GPIO_PIN_1
#define POWER_KEY_GPIO_Port GPIOA
#define N_RESET_Pin GPIO_PIN_3
#define N_RESET_GPIO_Port GPIOA
#define SPI1_MSS_Pin GPIO_PIN_4
#define SPI1_MSS_GPIO_Port GPIOA
#define ZCD_0_Pin GPIO_PIN_0
#define ZCD_0_GPIO_Port GPIOB
#define ZCD_0_EXTI_IRQn EXTI0_1_IRQn
#define ZCD_1_Pin GPIO_PIN_1
#define ZCD_1_GPIO_Port GPIOB
#define ZCD_1_EXTI_IRQn EXTI0_1_IRQn
#define ZCD_2_Pin GPIO_PIN_2
#define ZCD_2_GPIO_Port GPIOB
#define ZCD_2_EXTI_IRQn EXTI2_3_IRQn
#define LED_Pin GPIO_PIN_12
#define LED_GPIO_Port GPIOB
#define START_Pin GPIO_PIN_14
#define START_GPIO_Port GPIOB
#define START_EXTI_IRQn EXTI4_15_IRQn
#define STOP_Pin GPIO_PIN_15
#define STOP_GPIO_Port GPIOB
#define STOP_EXTI_IRQn EXTI4_15_IRQn
#define RELAY_4_Pin GPIO_PIN_8
#define RELAY_4_GPIO_Port GPIOA
#define RELAY_5_Pin GPIO_PIN_6
#define RELAY_5_GPIO_Port GPIOC
#define Relay_3_Pin GPIO_PIN_7
#define Relay_3_GPIO_Port GPIOC
#define Relay_2_Pin GPIO_PIN_11
#define Relay_2_GPIO_Port GPIOA
#define Relay_1_Pin GPIO_PIN_12
#define Relay_1_GPIO_Port GPIOA
#define TRIAC_1_Pin GPIO_PIN_15
#define TRIAC_1_GPIO_Port GPIOA
#define TRIAC_2_Pin GPIO_PIN_0
#define TRIAC_2_GPIO_Port GPIOD
#define TRIAC_3_Pin GPIO_PIN_1
#define TRIAC_3_GPIO_Port GPIOD
#define SSA1_Pin GPIO_PIN_2
#define SSA1_GPIO_Port GPIOD
#define SSA0_Pin GPIO_PIN_3
#define SSA0_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

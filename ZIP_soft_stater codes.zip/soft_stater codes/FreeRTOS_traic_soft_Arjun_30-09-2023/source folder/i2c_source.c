/*
 * i2c_source.c
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#include <i2c_source.h>

// char    buffer1[50];
 uint8_t val;

static const uint8_t MP2664_ADDR = 0x09 << 1;
/*


 void print_text(const char* text)
 {
	  //char uart_buf[50];
	  snprintf(buffer1, sizeof(buffer1), "%s\r\n",  text);


	  HAL_UART_Transmit(&huart3, (uint8_t*)buffer1, strlen(buffer1), HAL_MAX_DELAY);
 }

*/


 void I2C_tx(uint8_t regAddr, uint8_t data)
 {

 //  HAL_StatusTypeDef ret;


   // Tell MP2664 that we want to write to the specified register
   uint8_t txData[2];
   txData[0] = regAddr;
   txData[1] = data;

   //Writing the Data to MP2664
   HAL_I2C_Master_Transmit(&hi2c1, MP2664_ADDR, (uint8_t*)txData, 2, HAL_MAX_DELAY);

   HAL_Delay(500);


 }


 // Function to Read MP2664 Register Values
 void I2C_rx(uint8_t regAddr, uint8_t* dataBuffer)
 {
 //  HAL_StatusTypeDef ret;

   // Tell MP2664 that we want to read from the specified register

   HAL_I2C_Master_Transmit(&hi2c1, MP2664_ADDR, &regAddr, 1, HAL_MAX_DELAY);


   HAL_Delay(10);
   // Read 1 byte from the specified register

    HAL_I2C_Master_Receive(&hi2c1, MP2664_ADDR, &val, 1, HAL_MAX_DELAY);


 }

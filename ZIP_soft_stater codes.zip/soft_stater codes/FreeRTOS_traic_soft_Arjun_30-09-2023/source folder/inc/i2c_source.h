/*
 * i2c_source.h
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#ifndef INC_I2C_SOURCE_H_
#define INC_I2C_SOURCE_H_
#include <main.h>


/*void print_uart(void);
void print_text(const char* text);*/

void I2C_tx(uint8_t regAddr, uint8_t data);
void I2C_rx(uint8_t regAddr, uint8_t* dataBuffer);


//MP2664 I2C Register Includes
#define REG_INSC_ADDR 0x00
#define REG_PWOC_ADDR 0x01
#define REG_CHCC_ADDR 0x02
#define REG_PCTC_ADDR 0x03
#define REG_CHVC_ADDR 0x04
#define REG_CTTC_ADDR 0x05
#define REG_MSOC_ADDR 0x06
#define REG_SYST_ADDR 0x07
#define REG_FLTR_ADDR 0x08


#endif /* INC_I2C_SOURCE_H_ */

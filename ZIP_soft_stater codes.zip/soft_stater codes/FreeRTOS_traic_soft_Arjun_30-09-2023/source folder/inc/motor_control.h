/*
 * motor_control.h
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#ifndef INC_MOTOR_CONTROL_H_
#define INC_MOTOR_CONTROL_H_
#include <main.h>

void Motor_On();
void Motor_Off();

#endif /* INC_MOTOR_CONTROL_H_ */

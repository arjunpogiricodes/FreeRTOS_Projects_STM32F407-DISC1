/*
 * mqtt_quectel_source.h
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#ifndef INC_MQTT_QUECTEL_SOURCE_H_
#define INC_MQTT_QUECTEL_SOURCE_H_
#include <main.h>
void Motor_OFF_Publish();
void Motor_ON_Publish();
void MQTT_Motor_ON_OFF();
void Send_AT_Command(const char* cmd);
void MQTT_init_task (void );
void MQTT_Voltage_Upload();
void MQTT_Current_Upload();



#endif /* INC_MQTT_QUECTEL_SOURCE_H_ */

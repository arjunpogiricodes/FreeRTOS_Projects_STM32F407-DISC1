/*
 * mqtt_quectel_source.c
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */

#include <mqtt_quectel_source.h>


char valueStr[15];


float voltageA = 0;
float voltageB = 0;
float voltageC = 0;

float CurrentA = 0;
float CurrentB = 0;
float CurrentC = 0;

float voltageA_Prev = 0;
float voltageB_Prev = 0;
float voltageC_Prev = 0;

float CurrentA_Prev = 0;
float CurrentB_Prev = 0;
float CurrentC_Prev = 0;

/*void read_values (void)
{
	voltageA = GetLineVoltageA();
	voltageB = GetLineVoltageB();
	voltageC = GetLineVoltageC();


}*/
void Motor_OFF_Publish()
{
     	//print_text ( "motor off publish\r\n");
	  //Motor OFF Publish
	  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/motor\",3\r\n");
	  HAL_Delay(250);
	  Send_AT_Command("OFF");
	  HAL_Delay(1000);

}

void Motor_ON_Publish()
{
	  //print_text ( "motor on publish \r\n");
	  //Motor ON Publish
	  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/motor\",2\r\n");
	  HAL_Delay(250);
	  Send_AT_Command("ON");
	  HAL_Delay(1000);
}



void Send_AT_Command(const char* cmd) {
    HAL_UART_Transmit(&huart1, (uint8_t*)cmd, strlen(cmd), HAL_MAX_DELAY);
}


void MQTT_init_task (void )
{
    // Check SIM card status
    Send_AT_Command("AT+CPIN?\r\n");
    HAL_Delay(1000);

    // Check registered operator
    Send_AT_Command("AT+COPS?\r\n");
    HAL_Delay(1000);

    // Query for network info
    Send_AT_Command("AT+QNWINFO\r\n");
    HAL_Delay(1000);

    // Query network registration status
    Send_AT_Command("AT+CGREG?\r\n");
    HAL_Delay(1000);

    // Set network registration URC
    Send_AT_Command("AT+CGREG=2\r\n");
    HAL_Delay(1000);

    // Check network registration status again
    Send_AT_Command("AT+CGREG?\r\n");
    HAL_Delay(1000);

    // Check EPS network registration status
    Send_AT_Command("AT+CEREG?\r\n");
    HAL_Delay(1000);

    // Configure PDP context
    Send_AT_Command("AT+QICSGP=1,\"live.airtel.com\",\"\",\"\",1\r\n");
    HAL_Delay(1000);

    // Query PDP context activation status
    Send_AT_Command("AT+QIACT?\r\n");
    HAL_Delay(1000);

    // Activate PDP context
    Send_AT_Command("AT+QIACT=1\r\n");
    HAL_Delay(1000);

    // Check activation status again
    Send_AT_Command("AT+QIACT?\r\n");
    HAL_Delay(1000);

    // MQTT configurations
    Send_AT_Command("AT+QMTCFG=\"will\",0,1,1,1,\"will_topic\",\"offline_message\"\r\n");
    HAL_Delay(1000);
    Send_AT_Command("AT+QMTCFG=\"timeout\",0,60,5,1\r\n");
    HAL_Delay(1000);

    // Open a network with MQTT broker
    Send_AT_Command("AT+QMTOPEN=1,\"io.adafruit.com\",1883\r\n");
    HAL_Delay(5000);  // Wait for 5 seconds to allow connection
    // Connect to the broker
    Send_AT_Command("AT+QMTCONN=1,\"ARJUN POGIRI\",\"arjunpeepul\",\"aio_aEol36NPOUseRbAe58lpBfpHJNDh\"\r\n");
    HAL_Delay(5000);  // Wait for 5 seconds to allow connection
		     // Connect to the broker

}

void MQTT_Voltage_Upload()
{

	  voltageA = GetLineVoltageA();

	  //Upload the Values When there is there is change of 3 volts
	  if((fabs(voltageA - voltageA_Prev) > 1))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/voltagea\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", voltageA);

		  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);

	  }
	  voltageA_Prev = voltageA;



	  voltageB = GetLineVoltageB();

	  //Upload the Values When there is there is change of 3 volts
	  if((fabs(voltageB - voltageB_Prev) > 1 ))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/voltageb\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", voltageB);  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);
	  }
	  voltageB_Prev = voltageB;




	  voltageC = GetLineVoltageC();

	  //Upload the Values When there is there is change of 3 volts
	  if((fabs(voltageC - voltageC_Prev) > 1))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/voltagec\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", voltageC);  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);

	  }
	  voltageC_Prev = voltageC;


}



void MQTT_Current_Upload()
{


	  CurrentA = GetLineCurrentA();

	  if((fabs(CurrentA - CurrentA_Prev) > 0.1))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/currenta\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", CurrentA);  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);
	  }

	  CurrentA_Prev = CurrentA;




	  CurrentB = GetLineCurrentB();


	  if((fabs(CurrentB - CurrentB_Prev) > 0.1))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/currentb\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", CurrentB);  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);

	  }

	  CurrentB_Prev = CurrentB;





	  CurrentC = GetLineCurrentC();

	  if((fabs(CurrentC - CurrentC_Prev) > 0.1))
	  {
		  Send_AT_Command("AT+QMTPUBEX=1,2,1,0,\"arjunpeepul/feeds/currentc\",4\r\n");
		  HAL_Delay(250);

		  sprintf(valueStr, "%.2f", CurrentC);  // Convert the float value to a string with 1 decimal precision
		  Send_AT_Command(valueStr);
	  }

	  CurrentC_Prev = CurrentC;

}


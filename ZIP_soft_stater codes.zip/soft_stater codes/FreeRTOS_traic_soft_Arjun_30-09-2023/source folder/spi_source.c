/*
 * spi_source.c
 *
 *  Created on: Sep 26, 2023
 *      Author: arjun
 */
#include <spi_source.h>



char             uart_buff[50];
int              uart_buf_len;
unsigned short   vSagTh;
unsigned short   sagV;


void SelectSSAO(uint8_t select)
{

if (select)
{
  // Select the SSAO PIN

	HAL_GPIO_WritePin(GPIOD, SSA1_Pin|SSA0_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SPI1_MSS_GPIO_Port, SPI1_MSS_Pin, GPIO_PIN_RESET);
	HAL_Delay(3);

}
else
{
  // de-select the SSAO PIN

	HAL_GPIO_WritePin(GPIOD, SSA1_Pin|SSA0_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(SPI1_MSS_GPIO_Port, SPI1_MSS_Pin, GPIO_PIN_SET);

}
}

void spi_tx(uint16_t address, uint16_t data)

{

SelectSSAO(1);



//HAL_StatusTypeDef      ret;
uint16_t      spi_buff[2];
spi_buff[0] = address;
spi_buff[1] = data;

HAL_SPI_Transmit(&hspi1,(uint8_t *) spi_buff,2,HAL_MAX_DELAY);


while(HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY);
HAL_Delay(3);

SelectSSAO(0);

}


uint16_t spi_rx(uint16_t address)

{

uint16_t   value;

SelectSSAO(1);


//HAL_StatusTypeDef      ret;
uint16_t      spi_buff[1];
spi_buff[0] = address | 0x8000;

HAL_SPI_Transmit(&hspi1,(uint8_t *) spi_buff,1,150);
HAL_Delay(2);
uint8_t buffer[1];
HAL_SPI_Receive(&hspi1, (uint8_t*)buffer , 1, 100);

SelectSSAO(0);

value = ((uint16_t)buffer[1] << 8 )|((uint16_t) buffer[0]);

	if (value & 0x8000)
		 {
			 value -=  0x1000;
		  }




return   value;


}

unsigned short  CommEnergyIC (unsigned  char RW , unsigned short  address , unsigned short  value)
{

unsigned short output;

	if (RW)
	{

		output = spi_rx(address);

	}
	else
	{
		spi_tx(address , value);
	}
	return output;
}

int Read32Register(signed short regh_addr, signed short regl_addr) {

int val, val_h, val_l;
val_h = CommEnergyIC(1, regh_addr, 0xFFFF);
val_l = CommEnergyIC(1, regl_addr, 0xFFFF);
val   = CommEnergyIC(1, regh_addr, 0xFFFF);

val = val_h << 16;
val |= val_l; //concatenate the 2 registers to make 1 32 bit number

return (val);
}

void EM_Init(unsigned short lineFreq, unsigned short pgagain, unsigned short ugain,unsigned short igain)
{


sagV = 90;
vSagTh = (sagV * 100 * sqrt(2)) / (2 * ugain / 32768);

//Initialize registers
CommEnergyIC(WRITE, SoftReset,     0x789A);     // 70 Perform soft reset
CommEnergyIC(WRITE, CfgRegAccEn,   0x55AA);   // 7F enable register config access
CommEnergyIC(WRITE, MeterEn,       0x0001);       // 00 Enable Metering

CommEnergyIC(WRITE, SagPeakDetCfg, 0x143F); // 05 Sag and Voltage peak detect period set to 20ms
CommEnergyIC(WRITE, SagTh,         vSagTh);         // 08 Voltage sag threshold
CommEnergyIC(WRITE, FreqHiTh,      0x13EC);  // 0D High frequency threshold
CommEnergyIC(WRITE, FreqLoTh,      0X1324);  // 0C Lo frequency threshold
CommEnergyIC(WRITE, EMMIntEn0,     0xB76F);     // 75 Enable interrupts
CommEnergyIC(WRITE, EMMIntEn1,     0xDDFD);     // 76 Enable interrupts
CommEnergyIC(WRITE, EMMIntState0,  0x0001);  // 73 Clear interrupt flags
CommEnergyIC(WRITE, EMMIntState1,  0x0001);  // 74 Clear interrupt flags
CommEnergyIC(WRITE, ZXConfig,      0x4454);      // 07 ZX2, ZX1, ZX0 pin config - set to current channels, all polarity

//Set metering config values (CONFIG)
CommEnergyIC(WRITE, PLconstH,      0x0861);    // 31 PL Constant MSB (default) - Meter Constant = 3200 - PL Constant = 140625000
CommEnergyIC(WRITE, PLconstL,      0xC468);    // 32 PL Constant LSB (default) - this is 4C68 in the application note, which is incorrect
CommEnergyIC(WRITE, MMode0,      lineFreq);   // 33 Mode Config (frequency set in main program)
CommEnergyIC(WRITE, MMode1,      pgagain);    // 34 PGA Gain Configuration for Current Channels - 0x002A (x4) // 0x0015 (x2) // 0x0000 (1x)
CommEnergyIC(WRITE, PStartTh,      0x1424);    // 35 All phase Active Startup Power Threshold - 50% of startup current = 0.02A/0.00032 = 7500
CommEnergyIC(WRITE, QStartTh,      0x1424);    // 36 All phase Reactive Startup Power Threshold
CommEnergyIC(WRITE, SStartTh,      0x1424);    // 37 All phase Apparent Startup Power Threshold
CommEnergyIC(WRITE, PPhaseTh,      0x0158);    // 38 Each phase Active Phase Threshold = 10% of startup current = 0.002A/0.00032 = 750
CommEnergyIC(WRITE, QPhaseTh,      0x0158);    // 39 Each phase Reactive Phase Threshold
CommEnergyIC(WRITE, SPhaseTh,      0x0158);    // 3A Each phase Apparent Phase Threshold

//Set metering calibration values (CALIBRATION)
CommEnergyIC(WRITE, PQGainA,      0x0000);     // 47 Line calibration gain
CommEnergyIC(WRITE, PhiA,         0x0000);        // 48 Line calibration angle
CommEnergyIC(WRITE, PQGainB,      0x0000);     // 49 Line calibration gain
CommEnergyIC(WRITE, PhiB,         0x0000);        // 4A Line calibration angle
CommEnergyIC(WRITE, PQGainC,      0x800A);     // 4B Line calibration gain
CommEnergyIC(WRITE, PhiC,         0x0000);        // 4C Line calibration angle
CommEnergyIC(WRITE, PoffsetA,     0x0000);    // 41 A line active power offset FFDC
CommEnergyIC(WRITE, QoffsetA,     0x0000);    // 42 A line reactive power offset
CommEnergyIC(WRITE, PoffsetB,     0x0000);    // 43 B line active power offset
CommEnergyIC(WRITE, QoffsetB,     0x0000);    // 44 B line reactive power offset
CommEnergyIC(WRITE, PoffsetC,     0x0000);    // 45 C line active power offset
CommEnergyIC(WRITE, QoffsetC,     0x0000);    // 46 C line reactive power offset

//Set metering calibration values (HARMONIC)
CommEnergyIC(WRITE, POffsetAF,    0x0000);   // 51 A Fund. active power offset
CommEnergyIC(WRITE, POffsetBF,    0x0000);   // 52 B Fund. active power offset
CommEnergyIC(WRITE, POffsetCF,    0x0000);   // 53 C Fund. active power offset
CommEnergyIC(WRITE, PGainAF,      0x0000);     // 54 A Fund. active power gain
CommEnergyIC(WRITE, PGainBF,      0x0000);     // 55 B Fund. active power gain
CommEnergyIC(WRITE, PGainCF,      0x0000);     // 56 C Fund. active power gain

//Set measurement calibration values (ADJUST)
CommEnergyIC(WRITE, UgainA,        ugain);      // 61 A Voltage rms gain
CommEnergyIC(WRITE, IgainA,        igain);     // 62 A line current gain
CommEnergyIC(WRITE, UoffsetA,     0x0000);    // 63 A Voltage offset - 61A8
CommEnergyIC(WRITE, IoffsetA,     0x0000);    // 64 A line current offset - FE60
CommEnergyIC(WRITE, UgainB,        ugain);      // 65 B Voltage rms gain
CommEnergyIC(WRITE, IgainB,        igain);     // 66 B line current gain
CommEnergyIC(WRITE, UoffsetB,     0x0000);    // 67 B Voltage offset - 1D4C
CommEnergyIC(WRITE, IoffsetB,     0x0000);    // 68 B line current offset - FE60
CommEnergyIC(WRITE, UgainC,        ugain);      // 69 C Voltage rms gain
CommEnergyIC(WRITE, IgainC,        igain);     // 6A C line current gain
CommEnergyIC(WRITE, UoffsetC,     0x0000);    // 6B C Voltage offset - 1D4C
CommEnergyIC(WRITE, IoffsetC,     0x0000);    // 6C C line current offset

CommEnergyIC(WRITE, CfgRegAccEn,  0x0000); // 7F end configuration
HAL_Delay(50);
}




// VOLTAGE
double GetLineVoltageA() {
unsigned short voltage = CommEnergyIC(READ, UrmsA, 0xFFFF);
return ( double )voltage / 100;
}
double GetLineVoltageB() {
unsigned short voltage = CommEnergyIC(READ, UrmsB, 0xFFFF);
return ( double )voltage / 100;
}
double GetLineVoltageC() {
unsigned short voltage = CommEnergyIC(READ, UrmsC, 0xFFFF);
return ( double )voltage / 100;
}

// CURRENT
double GetLineCurrentA() {
unsigned short current = CommEnergyIC(READ, IrmsA, 0xFFFF);
return ( double )current / 1000;
}
double GetLineCurrentB() {
unsigned short current = CommEnergyIC(READ, IrmsB, 0xFFFF);
return ( double )current / 1000;
}
double GetLineCurrentC() {
unsigned short current = CommEnergyIC(READ, IrmsC, 0xFFFF);
return ( double )current / 1000;
}

double GetLineCurrentN() {
unsigned short current = CommEnergyIC(READ, IrmsN, 0xFFFF);
return ( double )current / 1000;
}

// ACTIVE POWER
double GetActivePowerA() {
int val = Read32Register(PmeanA, PmeanALSB);
return ( double )val * 0.00032;
}
double GetActivePowerB() {
int val = Read32Register(PmeanB, PmeanBLSB);
return ( double )val * 0.00032;
}
double GetActivePowerC() {
int val = Read32Register(PmeanC, PmeanCLSB);
return ( double )val * 0.00032;
}
double GetTotalActivePower() {
int val = Read32Register(PmeanT, PmeanTLSB);
return ( double )val * 0.00032;
}

// Active Fundamental Power
double GetTotalActiveFundPower() {
int val = Read32Register(PmeanTF, PmeanTFLSB);
return ( double )val * 0.00032;
}

// Active Harmonic Power
double GetTotalActiveHarPower() {
int val = Read32Register(PmeanTH, PmeanTHLSB);
return ( double )val * 0.00032;
}


// REACTIVE POWER
double GetReactivePowerA() {
int val = Read32Register(QmeanA, QmeanALSB);
return ( double )val * 0.00032;
}
double GetReactivePowerB() {
int val = Read32Register(QmeanB, QmeanBLSB);
return ( double )val * 0.00032;
}
double GetReactivePowerC() {
int val = Read32Register(QmeanC, QmeanCLSB);
return ( double )val * 0.00032;
}
double GetTotalReactivePower() {
int val = Read32Register(QmeanT, QmeanTLSB);
return ( double )val * 0.00032;
}

// APPARENT POWER
double GetApparentPowerA() {
int val = Read32Register(SmeanA, SmeanALSB);
return ( double )val * 0.00032;
}
double GetApparentPowerB() {
int val = Read32Register(SmeanB, SmeanBLSB);
return ( double )val * 0.00032;
}
double GetApparentPowerC() {
int val = Read32Register(SmeanC, SmeanCLSB);
return ( double )val * 0.00032;
}
double GetTotalApparentPower() {
int val = Read32Register(SmeanT, SAmeanTLSB);
return ( double )val * 0.00032;
}

// FREQUENCY
double GetFrequency() {
unsigned short freq = CommEnergyIC(READ, Freq, 0xFFFF);
return ( double )freq / 100;
}

// POWER FACTOR
double GetPowerFactorA() {
signed short pf = (signed short) CommEnergyIC(READ, PFmeanA, 0xFFFF);
return ( double )pf / 1000;
}
double GetPowerFactorB() {
signed short pf = (signed short) CommEnergyIC(READ, PFmeanB, 0xFFFF);
return ( double )pf / 1000;
}
double GetPowerFactorC() {
signed short pf = (signed short) CommEnergyIC(READ, PFmeanC, 0xFFFF);
return ( double )pf / 1000;
}
double GetTotalPowerFactor() {
signed short pf = (signed short) CommEnergyIC(READ, PFmeanT, 0xFFFF);
return ( double )pf / 1000;
}

// MEAN PHASE ANGLE
double GetPhaseA() {
unsigned short angleA = (unsigned short) CommEnergyIC(READ, PAngleA, 0xFFFF);
return ( double )angleA / 10;
}
double GetPhaseB() {
unsigned short angleB = (unsigned short) CommEnergyIC(READ, PAngleB, 0xFFFF);
return ( double )angleB / 10;
}
double GetPhaseC() {
unsigned short angleC = (unsigned short) CommEnergyIC(READ, PAngleC, 0xFFFF);
return ( double )angleC / 10;
}

// TEMPERATURE
double GetTemperature() {
short int atemp = (short int) CommEnergyIC(READ, Temp, 0xFFFF);
return ( double )atemp;
}

/* Gets the Register Value if Desired */
// REGISTER
double GetValueRegister(unsigned short registerRead) {
return ( double ) CommEnergyIC(READ, registerRead,     0xFFFF); //returns value register
}

// REGULAR ENERGY MEASUREMENT

// FORWARD ACTIVE ENERGY
// these registers accumulate energy and are cleared after being read
double GetImportEnergy() {
unsigned short ienergyT = CommEnergyIC(READ, APenergyT, 0xFFFF);
return ( double )ienergyT / 100 / 3200; //returns kWh
}


// FORWARD REACTIVE ENERGY
double GetImportReactiveEnergy() {
unsigned short renergyT = CommEnergyIC(READ, RPenergyT, 0xFFFF);
return ( double )renergyT / 100 / 3200; //returns kWh
}

// APPARENT ENERGY
double GetImportApparentEnergy() {
unsigned short senergyT = CommEnergyIC(READ, SAenergyT, 0xFFFF);
return ( double )senergyT / 100 / 3200; //returns kWh
}


// REVERSE ACTIVE ENERGY
double GetExportEnergy() {
unsigned short eenergyT = CommEnergyIC(READ, ANenergyT, 0xFFFF);
return ( double )eenergyT / 100 / 3200; //returns kWh
}


// REVERSE REACTIVE ENERGY
double GetExportReactiveEnergy() {
unsigned short reenergyT = CommEnergyIC(READ, RNenergyT, 0xFFFF);
return ( double )reenergyT / 100 / 3200; //returns kWh
}




/* System Status Registers */
unsigned short GetSysStatus0() {
return CommEnergyIC(READ, EMMIntState0, 0xFFFF);
}
unsigned shortGetSysStatus1() {
return CommEnergyIC(READ, EMMIntState1, 0xFFFF);
}
unsigned short GetMeterStatus0() {
return CommEnergyIC(READ, EMMState0,    0xFFFF);
}
unsigned short GetMeterStatus1() {
return CommEnergyIC(READ, EMMState1,    0xFFFF);
}



void Calibrate_V_I(float voltage,float current,float *calibration_parameter_v,float *calibration_parameter_c){

*calibration_parameter_v = (voltage/(GetValueRegister(0XDB)*0.01))*32768;
*calibration_parameter_c = (current/GetLineCurrentC())*32768;

}

double Total_Voltage(){

double q = GetLineVoltageA();
double w = GetLineVoltageB();
double e = GetLineVoltageC();
return (q+w+e)/3;
}



double LtoN_Voltage(int a)
{

double q;
double w;

if(a == 1){
	 q = GetLineVoltageA();
	 w = GetLineVoltageB();

}

else if(a == 2){
	 q = GetLineVoltageB();
	 w = GetLineVoltageC();

}
else if(a == 3){
	 q = GetLineVoltageC();
	 w = GetLineVoltageA();

}
return (q+w)/1.732;
}


double Total_Current(){

double temp1=GetLineCurrentA();
double temp2=GetLineCurrentB();
double temp3=GetLineCurrentC();

return (temp1+temp2+temp3)/3;

}

double Total_PF(){

double pf = GetTotalPowerFactor();
float abs_pf=fabs(pf);
return abs_pf;

}

double Total_Apparent_KVA(){

double vol=Total_Voltage();
double curr=Total_Current();
double kva = (vol*curr*1.732)/1000;
return kva;

}

double Total_Active_KW(){

double vol=Total_Voltage();
double curr=Total_Current();
double pf=Total_PF();
double kw = (vol*curr*pf*1.732)/1000;
return kw;

}

double Total_Reactive_KVAR(){

return (Total_Apparent_KVA()- Total_Active_KW());

}

double Total_Phase_Angle(){

double angle = acos(Total_PF()) * 180 / 3.141592;

return angle;
}


